package com.rohan.chesstournament.ChessGame;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.rohan.chesstournament.R;

import java.util.Objects;

public class GameModel {
    public static String[] row= {"1","2","3","4","5","6","7","8"};
    public static String[] column= {"A","B","C","D","E","F","G","H"};
    private int size;
    ImageView chesspiece;
    Context context;
    GridLayout chessboard;
    LinearLayout[][] square;
    Board board;
    int oldrow= -1;
    int oldcolumn = -1;
    public GameModel(Context context,GridLayout chessboard) {
        this.context=context;
        this.chessboard = chessboard;
        this.board = new Board();
        createChessboard();
        initializepiece();
    }

    public void createChessboard() {
        square = new LinearLayout[row.length][column.length];
        for (int i = 0; i < row.length; i++) {
            for (int j = 0; j < column.length; j++) {
                square[i][j] = new LinearLayout(context);
                square[i][j].setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                size = (Resources.getSystem().getDisplayMetrics().widthPixels / 8) - 12;
                square[i][j].setTag(row[i]+column[j]);
                square[i][j].setMinimumWidth(size);
                square[i][j].setMinimumHeight(size);
                updatecolor((i+j),square[i][j]);
                chessboard.addView(square[i][j]);
            }
        }
    }

    public void initializepiece(){
        for (int i = 0; i < row.length; i++) {
            for (int j = 0; j < column.length; j++) {
                if (board.getBox(i,j).getPiece() != null){
                  ChessPieces pieces = board.getBox(i,j).getPiece();
                    if (pieces.isKilled()){
//                    show piece outside
                    }else{
                        if (pieces.isWhite()){
                            displaypieces(i,j,"white_"+pieces.getName());
                        }else{
                            displaypieces(i,j,"black_"+pieces.getName());
                        }
                    }
                }else{
                    removepieces(i,j);
                }
            }
        }
    }

    public void displaypieces(int x,int y,String piece){
        chesspiece = new ImageView(context);
        LinearLayout.LayoutParams linearparam = new LinearLayout.LayoutParams(size-22, size-22);
        linearparam.gravity=Gravity.CENTER;
        linearparam.leftMargin=10;
        chesspiece.setLayoutParams(linearparam);
        chesspiece.setTag(new int[]{x, y});
        chesspiece.setBackgroundColor(context.getColor(android.R.color.transparent));
        chesspiece.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userclicked(view);
            }
        });
        Resources res = context.getResources();
        chesspiece.setImageResource(res.getIdentifier(piece, "drawable",context.getPackageName()));
        square[x][y].addView(chesspiece);
    }

    public void removepieces(int x,int y){
        square[x][y].removeAllViews();
    }

    public void userclicked(View v){
        int[] position = (int[]) v.getTag();
        int x = position[0];
        int y = position[1];
        Log.e("@@@",x+" "+y);
        if (x!=oldrow && y!=oldcolumn){
            square[x][y].setBackgroundColor(Color.parseColor("#d0e667"));
            if (oldrow != -1 && oldcolumn !=-1){
                Log.e("@@@","old not equal");
                updatecolor((oldcolumn+oldrow),square[oldrow][oldcolumn]);
                oldrow=-1;
                oldcolumn=-1;
            }else{
                Log.e("@@@","else");
                oldrow=x;
                oldcolumn=y;
            }
        }else {
            updatecolor((x+y),square[oldrow][oldcolumn]);
            oldrow=-1;
            oldcolumn=-1;
        }
    }

    public void updatecolor(int s,View v){
        if (s % 2 == 0){
            v.setBackgroundColor(Color.parseColor("#FFFFFF"));
        }else{
            v.setBackgroundColor(Color.parseColor("#808080"));
        }
    }

}
