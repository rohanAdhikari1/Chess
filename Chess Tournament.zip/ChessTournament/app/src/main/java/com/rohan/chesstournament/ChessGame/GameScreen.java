package com.rohan.chesstournament.ChessGame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;

import com.rohan.chesstournament.R;

public class GameScreen extends AppCompatActivity {
    GridLayout chessboard;
    GameModel gameModel;
    private static final int BOARD_SIZE = 8;

    private int selectedRow = -1;
    private int selectedCol = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);
        init();
    }

    private void init(){
        //initialize chessboard
        chessboard = findViewById(R.id.chessboard);
        chessboard.setOrientation(GridLayout.HORIZONTAL);
        chessboard.setColumnCount(BOARD_SIZE);
        chessboard.setRowCount(BOARD_SIZE);
        gameModel = new GameModel(this,chessboard);
    }



//    private void updateCellColor(int row, int col) {
//        if ((row + col) % 2 == 0) {
//            chessboxes[row][col].setBackgroundColor(Color.WHITE);
//        } else {
//            chessboxes[row][col].setBackgroundColor(Color.GRAY);
//        }
//    }
}