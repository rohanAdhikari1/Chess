package com.rohan.chesstournament;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.rohan.chesstournament.ChessGame.GameScreen;

public class MainActivity extends AppCompatActivity {
    static{
        System.loadLibrary("keys");
    }

    public native String getApikey();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent i = new Intent(this, GameScreen.class);
        startActivity(i);
        Log.e("@@@",getApikey());
    }
}