#include <jni.h>

JNIEXPORT jstring JNICALL
Java_com_rohan_chesstournament_MainActivity_getApikey(JNIEnv *env, jobject instance) {

return (*env)-> NewStringUTF(env, "TmF0aXZlNWVjcmV0UEBzc3cwcmQx");
}